# Distribuição automática de ocorrências: motor de regras V1

Objetivo: construir uma **tabela de sugestões** `ocorrência → racf sugerida + motivo`, a partir do estoque D0 sem `racf`. A sugestão é consumida e distribuída logo depois; na rodada seguinte a ocorrência volta com `racf` e sai das recomendações.

## Arquivos

| Arquivo | Função |
|---|---|
| `motor_distribuicao.py` | Executor da cascata de regras (pandas puro) |
| `regras_config.csv` | Ordem, `ativa` e `parametros` (JSON) de cada regra |
| `analistas.csv` | Analistas, tipos de atividade, seguradoras, faixas de segmento e arquétipos |
| `teste_motor.py` | Cenário fictício de validação (`python teste_motor.py`) |

**Atenção:** os dados de `analistas.csv`, o mapa de atribuição direta e o mapa segmento→faixa são **fictícios** e precisam ser substituídos por dados reais da operação.

## Decisão de abordagem

Motor de regras modular em cascata, com regras como dados e código como executor. Árvore de decisão e ML ficam para depois, como insumo de regras (tempo de tratamento, risco de SLA).

Por que não árvore agora: ela exige um rótulo confiável ("esta ocorrência deveria ter ido para X"), e o que existe é a decisão subjetiva do ponto focal (o mesmo cliente e assunto foram para analistas diferentes). Além disso, carga e disponibilidade mudam a cada atribuição, e a decisão precisa ser explicável.

| | Regras em cascata | Score ponderado | Árvore / ML |
|---|---|---|---|
| Explicabilidade | Total | Boa | Média/baixa |
| Precisa de histórico rotulado | Não | Não | Sim |
| Trata carga dinâmica | Sim | Sim | Mal |
| Adequação ao V1 | **Alta** | Média | Baixa |

## Cascata atual (ordem em `regras_config.csv`)

1. **elegibilidade** (filtro): analista ativo que atende o tipo de atividade e a seguradora. Campo vazio = sem restrição.
2. **atribuicao_direta**: tipo de atividade X → analista X.
3. **afinidade**: ranking por tratativas anteriores com o mesmo cliente (`cpf_cnpj`). Não decide sozinha.
4. **preferencia**: preferência declarada por faixa de segmento e arquétipo (ver abaixo).
5. **balanceamento**: escolhe o primeiro do ranking com carga abaixo do teto (`limiar_media` × média).
6. **fallback_menor_carga**: elegível com menos ocorrências.

Cada decisão grava `regra_aplicada`, `motivo` e `versao_regras`.

## Definição de carga

Número de ocorrências com `status` "Em andamento" ou "Em Fup" e `racf` preenchida, por analista. Contagem simples no V1. Analistas ausentes (férias, folga, treinamento, licença) ficam fora da média e do recebimento. A carga sobe +1 a cada atribuição dentro do lote.

## Afinidade (desenho aprovado; o código atual implementa o nível 2)

Busca em níveis, parando no primeiro com resultado:

| Nível | Critério | Janela sugerida |
|---|---|---|
| 1. Continuidade do caso | Mesmo cliente + mesmo assunto | 30 dias |
| 2. Conhece o cliente | Mesmo `cpf_cnpj` | 180 dias |
| 3. Conhece o tipo de demanda | Mesmo tipo de atividade + seguradora (+ produto) | 90 dias |

- Atendimentos recentes pesam mais (decaimento exponencial: 0,5 elevado a dias÷30).
- Parâmetros configuráveis: janelas, meia-vida, mínimo de tratativas, níveis ativos.
- Sem `cpf_cnpj`: pula os níveis 1 e 2. Sem histórico: passa para o fallback.
- Risco: o histórico reflete a distribuição manual atual. O teto de carga é o freio contra concentração; o nível 3 pode ser limitado aos 3 primeiros do ranking.
- Dados necessários: ocorrências encerradas com `racf`, `cpf_cnpj`, assunto e data de encerramento.

**Pendente no código:** níveis 1 e 3 e o decaimento por recência. Hoje a afinidade usa só a contagem por `cpf_cnpj`.

## Preferência por segmento e arquétipo (implementada)

- Cada analista declara `faixas_segmento` (pequeno, medio, grande) e `arquetipos`. Vazio = neutro.
- Segmento da ocorrência → faixa por mapa nos parâmetros da regra (TOP/BUSINESS = grande; PRO = medio; EMPREENDA/RENOVA = pequeno). "Não Segmentado", "ITAÚ AGÊNCIAS" e "PERSONNALITE" não geram preferência.
- Grupo preferido = analistas que batem explicitamente em ao menos uma dimensão e não contrariam nenhuma.
- Só monta o ranking quando a afinidade não encontrou histórico (a continuidade com o cliente vale mais).
- **Transbordo:** se o grupo preferido está acima do teto ou ausente, abre para os demais elegíveis e registra no motivo.
- Modo `preferencial` (padrão) ou `obrigatorio`, por dimensão, em `regras_config.csv`. Hoje nenhuma faixa obrigatória foi confirmada.
- Atenção: o arquétipo descreve a motivação de contratação, não o tipo da ocorrência. Validar com o ponto focal se distingue o atendimento.

## Arquitetura na AWS (proposta)

EventBridge Scheduler (de hora em hora) → Step Function:

1. Rotina existente que atualiza o estoque D0.
2. Job do motor (Glue Python Shell ou Lambda com pandas).
3. Gravação da tabela de sugestões no S3, consultável via Athena.
4. Falha → aviso por SNS ou e-mail.

Entradas: estoque D0, histórico de ocorrências encerradas, `book_pj` e as configurações.

## Configurações editáveis

As regras e os dados dos analistas ficam fora do código, em arquivos lidos a cada execução.

| Arquivo | Conteúdo | Mudança |
|---|---|---|
| `regras_config` | ordem, nome, ativa, parâmetros | Baixa |
| `analistas` | declarado: tipos, seguradoras, faixas, arquétipos (time e vínculo vêm da base organizacional) | Baixa |
| `ausencias` | racf, data_inicio, data_fim, motivo | Alta |

- Fonte da verdade: arquivos versionados no S3; o motor registra a versão usada.
- Interface de edição: SharePoint (lista ou Excel) sincronizado para o S3 via Power Automate. Plano B: upload manual.
- Validação antes do uso (colunas, racf existente, JSON válido); em caso de erro, usa a última versão válida e avisa.
- A habilidade "observada" (o que o analista de fato atendeu) não é materializada: é calculada na execução a partir do histórico no Athena.
- Disponibilidade do dia, em ordem de precedência: (1) override manual do ponto focal com `data_fim` padrão = hoje; (2) base de RH/escala, se acessível; (3) sinal operacional apenas como alerta (sem movimentação no dia), nunca como bloqueio automático.

## Tabela de saída (proposta)

| Coluna | Finalidade |
|---|---|
| `run_id`, `data_execucao` | Rastrear cada rodada |
| `numero_ocorrencia` | Chave para o consumidor |
| `racf_sugerida` | Recomendação |
| `regra_aplicada`, `motivo` | Explicação da decisão |
| `racf_alternativa` | Segundo colocado (**ainda não gerada**) |
| `cpf_cnpj_encontrado`, `perfil_conhecido` | Flags de qualidade (**ainda não geradas**) |
| `versao_regras` | Comparar versões das regras |

## Dados de entrada: pontos de atenção

- `book_pj`: base de ~417 mil CNPJs com seguro vigente (filtro `flag_seguro_vigente = 1`). Não cobre CPFs nem clientes sem apólice vigente; a fila mistura PF e PJ.
- Perfis (K-means): rótulos por regra sobre z-scores, **instáveis entre execuções** (o mesmo ID pode virar outro perfil). Para a distribuição, preferir variáveis brutas (faturamento, engajamento, apólices) ou uma versão congelada do modelo.
- Perfil é comercial, não operacional; usar só como sinal secundário.
- Cobertura do book sobre as ocorrências deve ser medida antes de definir o peso do perfil.
- Prioridade de cliente em cascata: faturamento → segmento → neutro.
- `assunto` é hierárquico (`Produto/Seguradora/Processo/Ação`): parsear por `/` preenche a seguradora e dá um indicador de complexidade.
- O mesmo cliente e assunto aparece em várias ocorrências para analistas diferentes; a afinidade resolve isso.

## Pendências

- [ ] Conectar o estoque D0 real.
- [ ] Conectar o histórico de ocorrências encerradas (alimenta a afinidade).
- [ ] Conectar a disponibilidade por data (férias e afastamentos).
- [ ] Conectar o `book_pj` e a cascata de prioridade.
- [ ] Implementar afinidade níveis 1 e 3 e decaimento por recência.
- [ ] Gerar `racf_alternativa`, `run_id`, `data_execucao` e flags de qualidade.
- [ ] Levantar com a operação: analistas reais, mapa de atribuição direta, ausências.
- [ ] Confirmar se Power Automate (ou integração SharePoint → AWS) está liberado.
- [ ] Medir a cobertura real do `book_pj` sobre as ocorrências.
- [ ] Decidir se o modo sombra (comparar `racf_sugerida` com a `racf` real) entra antes de usar as sugestões.
- [ ] Validar com a operação se existe faixa de segmento obrigatória por analista.
