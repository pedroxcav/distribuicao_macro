import pandas as pd
from motor_distribuicao import distribuir

est = pd.DataFrame([
 # carga atual
 *[dict(numero_ocorrencia=i, racf="CAYRTON", status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=1) for i in range(6)],
 *[dict(numero_ocorrencia=10+i, racf="CEBSOQD", status="Em Fup", tipo_atividade="Demanda PJ Corretora", dias_uteis=1) for i in range(2)],
 # estoque D0 sem racf
 dict(numero_ocorrencia=100, racf=None, status="Em andamento", tipo_atividade="Demandas Pós Venda Saúde", dias_uteis=2, cpf_cnpj="A", seguradora="Sul América"),
 dict(numero_ocorrencia=101, racf=None, status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=1, cpf_cnpj="B", seguradora="Prudential"),
 dict(numero_ocorrencia=102, racf=None, status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=0, cpf_cnpj="C", seguradora=None),
 dict(numero_ocorrencia=103, racf=None, status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=0, cpf_cnpj="D", seguradora=None, segmento="BUSINESS"),
 dict(numero_ocorrencia=104, racf=None, status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=0, cpf_cnpj="E", seguradora=None, segmento="PRO"),
 dict(numero_ocorrencia=105, racf=None, status="Em andamento", tipo_atividade="Demanda PJ Corretora", dias_uteis=0, cpf_cnpj="F", seguradora=None, segmento="Não Segmentado"),
])
hist = pd.DataFrame([dict(racf="CAYRTON", cpf_cnpj="C")]*5 + [dict(racf="CEBSOQD", cpf_cnpj="C")]*2)
an = pd.read_csv("analistas.csv")
print(distribuir(est, an, hist, "regras_config.csv")[["numero_ocorrencia","racf_sugerida","regra_aplicada","motivo"]].to_string(index=False))
