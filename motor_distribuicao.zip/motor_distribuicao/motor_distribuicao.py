"""
Motor de distribuição de ocorrências - V1 (cascata modular de regras).

Fluxo: estoque D0 (sem racf) -> ordena por prioridade -> para cada ocorrência
roda a cadeia de regras definida em regras_config.csv -> grava racf_sugerida + motivo.

Para criar uma regra nova: subclasse de Regra, decorada com @registrar("nome"),
e uma linha nova em regras_config.csv. Nenhuma outra parte do código muda.
"""
import json
from collections import Counter
from dataclasses import dataclass, field
import pandas as pd

VERSAO_REGRAS = "v1.0"
STATUS_CARGA = {"Em andamento", "Em Fup"}      # o que conta como carga


# ---------------------------------------------------------------- contexto
@dataclass
class Contexto:
    carga: Counter                 # racf -> nº de ocorrências em aberto (mutável)
    analistas: pd.DataFrame        # tabela de elegibilidade (só ativos)
    historico: pd.DataFrame        # atendimentos passados (racf, cpf_cnpj, data...)
    ranking_afinidade: list = field(default_factory=list)  # ranking de candidatos (afinidade ou preferência)
    origem_ranking: str = ""       # de onde veio o ranking (vai para o motivo)
    nota: str = ""                 # observação extra (ex.: transbordo) anexada ao motivo

    @property
    def media_carga(self):
        ativos = self.analistas["racf"].tolist()
        return sum(self.carga[r] for r in ativos) / max(len(ativos), 1)


@dataclass
class Resultado:
    candidatos: list               # lista (possivelmente filtrada) de racf
    decisao: str | None = None     # racf escolhido, se a regra decidiu
    motivo: str = ""


# ---------------------------------------------------------------- regras
REGISTRO = {}
def registrar(nome):
    def deco(cls):
        REGISTRO[nome] = cls
        return cls
    return deco


class Regra:
    def __init__(self, nome, params):
        self.nome, self.params = nome, params
    def aplicar(self, oc, candidatos, ctx) -> Resultado:
        raise NotImplementedError


def _lista(v):
    """'A|B' -> ['A','B']; vazio/NaN -> [] (vazio = sem restrição)."""
    return [] if pd.isna(v) else [x for x in str(v).split("|") if x]


@registrar("elegibilidade")
class Elegibilidade(Regra):
    """Filtro: só quem atende o tipo de atividade / seguradora da ocorrência."""
    def aplicar(self, oc, candidatos, ctx):
        ok = []
        for _, a in ctx.analistas[ctx.analistas["racf"].isin(candidatos)].iterrows():
            tipos = _lista(a.get("tipos_atividade"))
            segs = _lista(a.get("seguradoras"))
            if tipos and oc["tipo_atividade"] not in tipos:
                continue
            if segs and not pd.isna(oc.get("seguradora")) and oc["seguradora"] not in segs:
                continue
            ok.append(a["racf"])
        return Resultado(ok, motivo="filtro de elegibilidade")


@registrar("atribuicao_direta")
class AtribuicaoDireta(Regra):
    """tipo_atividade X -> analista X (mapa vem dos parâmetros)."""
    def aplicar(self, oc, candidatos, ctx):
        alvo = self.params.get("mapa", {}).get(oc["tipo_atividade"])
        if alvo and alvo in candidatos:
            return Resultado(candidatos, alvo, f"atribuição direta: {oc['tipo_atividade']}")
        return Resultado(candidatos)


@registrar("afinidade")
class Afinidade(Regra):
    """Ordena candidatos por nº de tratativas anteriores com o mesmo cliente.
    Não decide sozinha: deixa o ranking para a regra de balanceamento."""
    def aplicar(self, oc, candidatos, ctx):
        chave = self.params.get("chave", "cpf_cnpj")
        h = ctx.historico
        if h.empty or pd.isna(oc.get(chave)):
            return Resultado(candidatos)
        h = h[(h[chave] == oc[chave]) & (h["racf"].isin(candidatos))]
        cont = h["racf"].value_counts()
        ctx.ranking_afinidade = list(cont.index)
        ctx.origem_ranking = "afinidade com o cliente"
        return Resultado(candidatos)


@registrar("preferencia")
class Preferencia(Regra):
    """Preferência declarada por faixa de segmento e por arquétipo.
    - Analista com coluna vazia = sem preferência naquela dimensão (neutro).
    - 'preferido' = bate explicitamente em >=1 dimensão e não contraria nenhuma.
    - modo 'preferencial': só monta o ranking se a afinidade não montou um
      (continuidade com o cliente vale mais); se o grupo estiver acima do teto,
      o balanceamento deixa passar e o fallback abre para todos (transbordo).
    - modo 'obrigatorio' (por dimensão): restringe os candidatos ao grupo."""
    DIMENSOES = {"faixa_segmento": "faixas_segmento", "arquetipo": "arquetipos"}

    def _valor_oc(self, oc, dim):
        if dim == "faixa_segmento":
            seg = oc.get("segmento")
            faixa = None if pd.isna(seg) else self.params.get("faixas", {}).get(str(seg).strip().upper())
            return faixa.upper() if faixa else None
        v = oc.get("arquetipo")
        return None if pd.isna(v) else str(v).strip().upper()

    def aplicar(self, oc, candidatos, ctx):
        modos = self.params.get("modos", {})
        base = ctx.analistas.set_index("racf")
        score = {}
        for r in candidatos:
            n, contraria = 0, False
            for dim, col in self.DIMENSOES.items():
                val = self._valor_oc(oc, dim)
                decl = [x.upper() for x in _lista(base.loc[r].get(col))]
                if val is None or not decl:
                    continue
                if val in decl: n += 1
                else: contraria = True
            score[r] = (n, contraria)

        # dimensões obrigatórias: filtra candidatos
        obrig = [d for d in self.DIMENSOES if modos.get(d) == "obrigatorio"]
        if obrig:
            ok = []
            for r in candidatos:
                col_ok = True
                for dim in obrig:
                    val = self._valor_oc(oc, dim)
                    decl = [x.upper() for x in _lista(base.loc[r].get(self.DIMENSOES[dim]))]
                    if val is not None and decl and val not in decl:
                        col_ok = False
                if col_ok: ok.append(r)
            if ok: candidatos = ok

        grupo = [r for r in candidatos if score[r][0] >= 1 and not score[r][1]]
        if grupo and not ctx.ranking_afinidade:
            ctx.ranking_afinidade = sorted(grupo, key=lambda r: (ctx.carga[r], r))
            ctx.origem_ranking = "preferência por segmento/arquétipo"
        return Resultado(candidatos, motivo="preferência aplicada")


@registrar("balanceamento")
class Balanceamento(Regra):
    """Percorre o ranking de afinidade e escolhe o primeiro abaixo do teto de carga."""
    def aplicar(self, oc, candidatos, ctx):
        teto = ctx.media_carga * self.params.get("limiar_media", 1.2)
        for i, r in enumerate(ctx.ranking_afinidade):
            if r in candidatos and (ctx.carga[r] <= teto or ctx.media_carga == 0):
                extra = "" if i == 0 else f" (pulou {i} acima do teto de carga)"
                return Resultado(candidatos, r, f"{ctx.origem_ranking}{extra}")
        if ctx.ranking_afinidade:
            ctx.nota = f" | transbordo: {ctx.origem_ranking} acima do teto de carga"
        return Resultado(candidatos)


@registrar("fallback_menor_carga")
class FallbackMenorCarga(Regra):
    def aplicar(self, oc, candidatos, ctx):
        if not candidatos:
            return Resultado([], None, "sem analista elegível")
        r = min(candidatos, key=lambda x: (ctx.carga[x], x))
        return Resultado(candidatos, r, "menor carga entre os elegíveis" + ctx.nota)


# ---------------------------------------------------------------- motor
def carregar_regras(caminho):
    cfg = pd.read_csv(caminho).sort_values("ordem")
    cfg = cfg[cfg["ativa"] == 1]
    return [REGISTRO[r.nome_regra](r.nome_regra, json.loads(r.parametros)) for r in cfg.itertuples()]


def distribuir(estoque, analistas, historico, config_regras):
    """estoque: DataFrame de ocorrências em D0 (todas, com e sem racf)."""
    ativos = analistas[analistas["ativo"] == 1].copy()
    em_aberto = estoque[estoque["status"].isin(STATUS_CARGA) & estoque["racf"].notna()]
    ctx = Contexto(Counter(em_aberto["racf"]), ativos, historico)
    regras = carregar_regras(config_regras)

    pendentes = estoque[estoque["racf"].isna()].copy()
    pendentes = pendentes.sort_values("dias_uteis", ascending=False)  # mais velhas primeiro

    saida = []
    for _, oc in pendentes.iterrows():
        oc = oc.to_dict()
        candidatos, decisao, motivo, regra_ap = ativos["racf"].tolist(), None, "", ""
        ctx.ranking_afinidade, ctx.origem_ranking, ctx.nota = [], "", ""
        for regra in regras:
            res = regra.aplicar(oc, candidatos, ctx)
            candidatos = res.candidatos
            if res.decisao:
                decisao, motivo, regra_ap = res.decisao, res.motivo, regra.nome
                break
        if decisao:
            ctx.carga[decisao] += 1          # atualiza a carga para a próxima ocorrência
        saida.append({**oc, "racf_sugerida": decisao, "regra_aplicada": regra_ap,
                      "motivo": motivo or "sem decisão", "versao_regras": VERSAO_REGRAS})
    return pd.DataFrame(saida)
